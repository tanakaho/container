import UIKit


let taxRate = 0.08

var productX = 8000.0
var productY = 6000.0

productX * taxRate


productY * taxRate




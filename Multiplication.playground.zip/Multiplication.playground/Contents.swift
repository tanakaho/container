import UIKit

var x = 9

var i = 1

for i in 1...9{
print(i * x)
}

for i in 1...9 {
    for j in 1...9{
        print(i * j)
    }
}
